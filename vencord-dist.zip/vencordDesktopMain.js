// Vencord 88075640
// Standalone: false
// Platform: win32
// Updater Disabled: false
"use strict";var er=Object.create;var Ee=Object.defineProperty;var tr=Object.getOwnPropertyDescriptor;var nr=Object.getOwnPropertyNames;var rr=Object.getPrototypeOf,ir=Object.prototype.hasOwnProperty;var Re=(t,e)=>()=>(t&&(e=t(t=0)),e);var $=(t,e)=>{for(var n in e)Ee(t,n,{get:e[n],enumerable:!0})},Tt=(t,e,n,r)=>{if(e&&typeof e=="object"||typeof e=="function")for(let i of nr(e))!ir.call(t,i)&&i!==n&&Ee(t,i,{get:()=>e[i],enumerable:!(r=tr(e,i))||r.enumerable});return t};var bt=(t,e,n)=>(n=t!=null?er(rr(t)):{},Tt(e||!t||!t.__esModule?Ee(n,"default",{value:t,enumerable:!0}):n,t)),or=t=>Tt(Ee({},"__esModule",{value:!0}),t);var c=Re(()=>{"use strict"});var se=Re(()=>{"use strict";c()});function Ie(t){return async function(){try{return{ok:!0,value:await t(...arguments)}}catch(e){return{ok:!1,error:e instanceof Error?{...e,message:e.message,name:e.name,stack:e.stack}:e}}}}var Lt=Re(()=>{"use strict";c()});var gr={};function ce(...t){let e={cwd:Gt};return Je?Ye("flatpak-spawn",["--host","git",...t],e):Ye("git",t,e)}async function ur(){return(await ce("remote","get-url","origin")).stdout.trim().replace(/git@(.+):/,"https://$1/").replace(/\.git$/,"")}async function fr(){await ce("fetch");let t=(await ce("branch","--show-current")).stdout.trim();if(!((await ce("ls-remote","origin",t)).stdout.length>0))return[];let r=(await ce("log",`HEAD...origin/${t}`,"--pretty=format:%an/%h/%s")).stdout.trim();return r?r.split(`
`).map(i=>{let[o,s,...a]=i.split("/");return{hash:s,author:o,message:a.join("/").split(`
`)[0]}}):[]}async function hr(){return(await ce("pull")).stdout.includes("Fast-forward")}async function pr(){return!(await Ye(Je?"flatpak-spawn":"node",Je?["--host","node","scripts/build/build.mjs"]:["scripts/build/build.mjs"],{cwd:Gt})).stderr.includes("Build failed")}var Nt,Ae,Ut,Vt,Gt,Ye,Je,zt=Re(()=>{"use strict";c();se();Nt=require("child_process"),Ae=require("electron"),Ut=require("path"),Vt=require("util");Lt();Gt=(0,Ut.join)(__dirname,".."),Ye=(0,Vt.promisify)(Nt.execFile),Je=!1;Ae.ipcMain.handle("VencordGetRepo",Ie(ur));Ae.ipcMain.handle("VencordGetUpdates",Ie(fr));Ae.ipcMain.handle("VencordUpdate",Ie(hr));Ae.ipcMain.handle("VencordBuild",Ie(pr))});c();var ee=require("electron"),$n=require("path"),mt=require("url");c();c();se();c();var Be=Symbol("SettingsStore.isProxy"),Et=Symbol("SettingsStore.getRawTarget"),ye=class{pathListeners=new Map;globalListeners=new Set;proxyContexts=new WeakMap;proxyHandler=(()=>{let e=this;return{get(n,r,i){if(r===Be)return!0;if(r===Et)return n;let o=Reflect.get(n,r,i),s=e.proxyContexts.get(n);if(s==null)return o;let{root:a,path:u}=s;if(!(r in n)&&e.getDefaultValue!=null&&(o=e.getDefaultValue({target:n,key:r,root:a,path:u})),typeof o=="object"&&o!==null&&!o[Be]){let d=`${u}${u&&"."}${r}`;return e.makeProxy(o,a,d)}return o},set(n,r,i){if(i?.[Be]&&(i=i[Et]),n[r]===i)return!0;if(!Reflect.set(n,r,i))return!1;let o=e.proxyContexts.get(n);if(o==null)return!0;let{root:s,path:a}=o,u=`${a}${a&&"."}${r}`;return e.notifyListeners(u,i,s),!0},deleteProperty(n,r){if(!Reflect.deleteProperty(n,r))return!1;let i=e.proxyContexts.get(n);if(i==null)return!0;let{root:o,path:s}=i,a=`${s}${s&&"."}${r}`;return e.notifyListeners(a,void 0,o),!0}}})();constructor(e,n={}){this.plain=e,this.store=this.makeProxy(e),Object.assign(this,n)}makeProxy(e,n=e,r=""){return this.proxyContexts.set(e,{root:n,path:r}),new Proxy(e,this.proxyHandler)}notifyListeners(e,n,r){let i=e.split(".");if(i.length>3&&i[0]==="plugins"){let o=i.slice(0,3),s=o.join("."),a=o.reduce((u,d)=>u[d],r);this.globalListeners.forEach(u=>u(r,s)),this.pathListeners.get(s)?.forEach(u=>u(a))}else this.globalListeners.forEach(o=>o(r,e));this.pathListeners.get(e)?.forEach(o=>o(n))}setData(e,n){if(this.readOnly)throw new Error("SettingsStore is read-only");if(this.plain=e,this.store=this.makeProxy(e),n){let r=e,i=n.split(".");for(let o of i){if(!r){console.warn(`Settings#setData: Path ${n} does not exist in new data. Not dispatching update`);return}r=r[o]}this.pathListeners.get(n)?.forEach(o=>o(r))}this.markAsChanged()}addGlobalChangeListener(e){this.globalListeners.add(e)}addChangeListener(e,n){let r=this.pathListeners.get(e)??new Set;r.add(n),this.pathListeners.set(e,r)}removeGlobalChangeListener(e){this.globalListeners.delete(e)}removeChangeListener(e,n){let r=this.pathListeners.get(e);r&&(r.delete(n),r.size||this.pathListeners.delete(e))}markAsChanged(){this.globalListeners.forEach(e=>e(this.plain,""))}};c();function Fe(t,e){for(let n in e){let r=e[n];typeof r=="object"&&!Array.isArray(r)?(t[n]??={},Fe(t[n],r)):t[n]??=r}return t}var We=require("electron"),X=require("fs");c();var Rt=require("electron"),K=require("path"),De=process.env.VENCORD_USER_DATA_DIR??(process.env.DISCORD_USER_DATA_DIR?(0,K.join)(process.env.DISCORD_USER_DATA_DIR,"..","VencordData"):(0,K.join)(Rt.app.getPath("userData"),"..","Vencord")),Y=(0,K.join)(De,"settings"),J=(0,K.join)(De,"themes"),Pe=(0,K.join)(Y,"quickCss.css"),je=(0,K.join)(Y,"settings.json"),Ze=(0,K.join)(Y,"native-settings.json"),Dt=["https:","http:","steam:","spotify:","com.epicgames.launcher:","tidal:","itunes:"];(0,X.mkdirSync)(Y,{recursive:!0});function Pt(t,e){try{return JSON.parse((0,X.readFileSync)(e,"utf-8"))}catch(n){return n?.code!=="ENOENT"&&console.error(`Failed to read ${t} settings`,n),{}}}var O=new ye(Pt("renderer",je));O.addGlobalChangeListener(()=>{try{(0,X.writeFileSync)(je,JSON.stringify(O.plain,null,4))}catch(t){console.error("Failed to write renderer settings",t)}});We.ipcMain.on("VencordGetSettings",t=>t.returnValue=O.plain);We.ipcMain.handle("VencordSetSettings",(t,e,n)=>{O.setData(e,n)});var sr={plugins:{},customCspRules:{}},kt=Pt("native",Ze);Fe(kt,sr);var U=new ye(kt);U.addGlobalChangeListener(()=>{try{(0,X.writeFileSync)(Ze,JSON.stringify(U.plain,null,4))}catch(t){console.error("Failed to write native settings",t)}});var Ke=require("electron"),ae=["connect-src"],M=[...ae,"img-src"],Mt=["style-src","font-src"],C=[...M,...Mt],Ot=[...C,"script-src","worker-src"],$e={"http://localhost:*":C,"http://127.0.0.1:*":C,"localhost:*":C,"127.0.0.1:*":C,"*.github.io":C,"github.com":C,"raw.githubusercontent.com":C,"*.gitlab.io":C,"gitlab.com":C,"*.codeberg.page":C,"codeberg.org":C,"*.githack.com":C,"jsdelivr.net":C,"fonts.googleapis.com":Mt,"i.imgur.com":M,"i.ibb.co":M,"i.pinimg.com":M,"*.tenor.com":M,"files.catbox.moe":C,"cdn.discordapp.com":C,"media.discordapp.net":M,"cdnjs.cloudflare.com":Ot,"cdn.jsdelivr.net":Ot,"api.github.com":ae,"ws.audioscrobbler.com":ae,"translate-pa.googleapis.com":ae,"*.vencord.dev":M,"manti.vendicated.dev":M,"decor.fieryflames.dev":ae,"ugc.decor.fieryflames.dev":M,"sponsor.ajay.app":ae,"dearrow-thumb.ajay.app":M,"usrbg.is-hardly.online":M,"icons.duckduckgo.com":M},He=(t,e)=>Object.keys(t).find(n=>n.toLowerCase()===e),ar=t=>{let e={};return t.split(";").forEach(n=>{let[r,...i]=n.trim().split(/\s+/g);r&&!Object.prototype.hasOwnProperty.call(e,r)&&(e[r]=i)}),e},cr=t=>Object.entries(t).filter(([,e])=>e?.length).map(e=>e.flat().join(" ")).join("; "),lr=t=>{let e=He(t,"content-security-policy-report-only");e&&delete t[e];let n=He(t,"content-security-policy");if(n){let r=ar(t[n][0]),i=(o,...s)=>{r[o]??=[...r["default-src"]??[]],r[o].push(...s)};i("style-src","'unsafe-inline'"),i("script-src","'unsafe-inline'","'unsafe-eval'");for(let o of["style-src","connect-src","img-src","font-src","media-src","worker-src"])i(o,"blob:","data:","vencord:");for(let[o,s]of Object.entries(U.store.customCspRules))for(let a of s)i(a,o);for(let[o,s]of Object.entries($e))for(let a of s)i(a,o);t[n]=[cr(r)]}};function _t(){Ke.session.defaultSession.webRequest.onHeadersReceived(({responseHeaders:t,resourceType:e},n)=>{if(t&&(e==="mainFrame"&&lr(t),e==="stylesheet")){let r=He(t,"content-type");r&&(t[r]=["text/css"])}n({cancel:!1,responseHeaders:t})}),Ke.session.defaultSession.webRequest.onHeadersReceived=()=>{}}c();c();zt();c();se();var at=require("electron");c();var et={};$(et,{fetchTrackData:()=>Sr});c();c();c();c();var y=11400714785074694791n,S=14029467366897019727n,Bt=1609587929392839161n,Ce=9650029242287828579n,Ft=2870177450012600261n,Zt=64n,dr=2n**Zt-1n,mr=new TextEncoder;function jt(t,e,n,r){return BigInt(t)|BigInt(e)<<16n|BigInt(n)<<32n|BigInt(r)<<48n}function F(t,e){return BigInt(t[e])|BigInt(t[e+1])<<8n|BigInt(t[e+2])<<16n|BigInt(t[e+3])<<24n|BigInt(t[e+4])<<32n|BigInt(t[e+5])<<40n|BigInt(t[e+6])<<48n|BigInt(t[e+7])<<56n}function A(t,e){return t<<e&dr|t>>Zt-e}function f(t){return BigInt.asUintN(64,t)}var Xe=class{#t;#n;#r;#i;#o;#s;#a;#e;constructor(e=0){this.reset(e)}reset(e=this.#t){return this.#t=BigInt.asUintN(32,BigInt(e)),this.#n=f(this.#t+y+S),this.#r=f(this.#t+S),this.#i=this.#t,this.#o=f(this.#t-y),this.#s=null,this.#a=0,this.#e=0,this}update(e){typeof e=="string"&&(e=mr.encode(e));let n=0,r=e.length,i=n+r;if(r===0)return this;if(this.#a+=r,this.#e===0&&(this.#s=new Uint8Array(32)),this.#e+r<32)return this.#s.set(e.subarray(0,r),this.#e),this.#e+=r,this;if(this.#e>0){this.#s.set(e.subarray(0,32-this.#e),this.#e);let o=0,s;s=F(this.#s,o),this.#n=f(A(f(this.#n+s*S),31n)*y),o+=8,s=F(this.memory,o),this.#r=f(A(f(this.#r+s*S),31n)*y),o+=8,s=F(this.memory,o),this.#i=f(A(f(this.#i+s*S),31n)*y),o+=8,s=F(this.memory,o),this.#o=f(A(f(this.#o+s*S),31n)*y),n+=32-this.#e,this.#e=0}if(n<=i-32){let o=i-32;do{let s;s=F(e,n),this.#n=f(A(f(this.#n+s*S),31n)*y),n+=8,s=F(e,n),this.#r=f(A(f(this.#r+s*S),31n)*y),n+=8,s=F(e,n),this.#i=f(A(f(this.#i+s*S),31n)*y),n+=8,s=F(e,n),this.#o=f(A(f(this.#o+s*S),31n)*y),n+=8}while(n<=o)}return n<i&&(this.#s.set(e.subarray(n,i),this.#e),this.#e=i-n),this}digest(){let e=this.#s,n=this.#e,r=0,i=0n,o=0n,s=0n;for(this.#a>=32?(i=A(this.#n,1n)+A(this.#r,7n)+A(this.#i,12n)+A(this.#o,18n),i=f(i^A(f(this.#n*S),31n)*y),i=f(i*y+Ce),i=f(i^A(f(this.#r*S),31n)*y),i=f(i*y+Ce),i=f(i^A(f(this.#i*S),31n)*y),i=f(i*y+Ce),i=f(i^A(f(this.#o*S),31n)*y),i=f(i*y+Ce)):i=f(this.#t+Ft),i+=BigInt(this.#a);r<=n-8;)s=F(e,r),s=f(A(f(s*S),31n)*y),i=f(A(i^s,27n)*y+Ce),r+=8;for(r+4<=n&&(s=jt(e[r+1]<<8|e[r],e[r+3]<<8|e[r+2],0,0),i=f(A(i^f(s*y),23n)*S+Bt),r+=4);r<n;)s=jt(e[r++],0,0,0),i=f(A(i^f(s*Ft),11n)*y);return o=f(i>>33n),i=f((i^o)*S),o=f(i>>29n),i=f((i^o)*Bt),o=f(i>>32n),i=f(i^o),i}};function Wt(t,e=0){return new Xe(e).update(t).digest()}var le="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split(""),vr=(()=>{let t=new Uint8Array(4),e=new Uint32Array(t.buffer);return!((e[0]=1)&t[0])})();function yr(t){t=BigInt(t);let e=[],n=Math.ceil(Math.floor(Math.log2(Number(t))+1)/8);for(let i=0;i<n;i++)e.unshift(Number(t>>BigInt(8*i)&BigInt(255)));let r=new Uint8Array(e);return vr?r:r.reverse()}function Kt(t){let e=Wt(t,0),n=yr(e);return[le[n[0]>>2],le[(n[0]&3)<<4|n[1]>>4],le[(n[1]&15)<<2|n[2]>>6],le[n[2]&63],le[n[3]>>2],le[(n[3]&3)<<4|n[3]>>4]].join("")}function Ht(t){let e=typeof t=="string"?t:t.source;if(e=e.replaceAll(/#{intl::([\w$+/]*)(?:::(\w+))?}/g,(i,o,s)=>{let a=s==="raw"?o:Kt(o),u=typeof t=="string";return!Number.isNaN(Number(a[0]))||a.includes("+")||a.includes("/")?u?`["${a}"]`:String.raw`(?:\["${a}"\])`.replaceAll("+","\\+"):u?`.${a}`:String.raw`(?:\.${a})`}),typeof t=="string")return e;let n=e.replaceAll("\\i",String.raw`(?:[A-Za-z_$][\w$]*)`),r=new RegExp(n,t.flags);return r.toString=t.toString.bind(t),r}var $t=require("child_process"),Yt=require("util"),Jt=(0,Yt.promisify)($t.execFile);async function qe(t){let{stdout:e}=await Jt("osascript",t.map(n=>["-e",n]).flat());return e}var L=null,Ir=/<script type="module" crossorigin src="([a-zA-Z0-9.\-/]+)"><\/script>/,Ar=Ht(/\b(\i)="([A-Za-z0-9-_]*\.[A-Za-z0-9-_]*\.[A-Za-z0-9-_]*)"(?=.+?Bearer \$\{\1\})/),Qe,Cr=async()=>{if(Qe)return Qe;let t=await fetch("https://music.apple.com/").then(i=>i.text()),e=new URL(t.match(Ir)[1],"https://music.apple.com/"),r=(await fetch(e).then(i=>i.text())).match(Ar)[2];return Qe=r,r};async function wr({id:t,name:e,artist:n,album:r}){if(t===L?.id){if("data"in L)return L.data;if("failures"in L&&L.failures>=5)return null}try{let i=new URL("https://amp-api-edge.music.apple.com/v1/catalog/us/search");i.searchParams.set("platform","web"),i.searchParams.set("l","en-US"),i.searchParams.set("limit","1"),i.searchParams.set("with","serverBubbles"),i.searchParams.set("types","songs"),i.searchParams.set("term",`${e} ${n} ${r}`),i.searchParams.set("include[songs]","artists");let o=await Cr(),s=await fetch(i,{headers:{accept:"*/*","accept-language":"en-US,en;q=0.9",authorization:`Bearer ${o}`,"user-agent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",origin:"https://music.apple.com"}}).then(a=>a.json()).then(a=>a.results.song.data[0]);return L={id:t,data:{appleMusicLink:s.attributes.url,songLink:`https://song.link/i/${s.id}`,albumArtwork:s.attributes.artwork.url.replace("{w}x{h}","512x512"),artistArtwork:s.relationships.artists.data[0].attributes.artwork.url.replace("{w}x{h}","512x512")}},L.data}catch(i){return console.error("[AppleMusicRichPresence] Failed to fetch remote data:",i),L={id:t,failures:(t===L?.id&&"failures"in L?L.failures:0)+1},null}}async function Sr(){try{await Jt("pgrep",["^Music$"])}catch{return null}if(await qe(['tell application "Music"',"get player state","end tell"]).then(h=>h.trim())!=="playing")return null;let e=await qe(['tell application "Music"',"get player position","end tell"]).then(h=>Number.parseFloat(h.trim())),n=await qe(['set output to ""','tell application "Music"',"set t_id to database id of current track","set t_name to name of current track","set t_album to album of current track","set t_artist to artist of current track","set t_duration to duration of current track",'set output to "" & t_id & "\\n" & t_name & "\\n" & t_album & "\\n" & t_artist & "\\n" & t_duration',"end tell","return output"]),[r,i,o,s,a]=n.split(`
`).filter(h=>!!h),u=Number.parseFloat(a),d=await wr({id:r,name:i,artist:s,album:o});return{name:i,album:o,artist:s,playerPosition:e,duration:u,...d}}var tt={};$(tt,{initDevtoolsOpenEagerLoad:()=>xr});c();function xr(t){let e=()=>t.sender.executeJavaScript("Vencord.Plugins.plugins.ConsoleShortcuts.eagerLoad(true)");t.sender.isDevToolsOpened()?e():t.sender.once("devtools-opened",()=>e())}var qt={};c();var Xt=require("electron");Xt.app.on("browser-window-created",(t,e)=>{e.webContents.on("frame-created",(n,{frame:r})=>{r?.once("dom-ready",()=>{if(r.url.startsWith("https://open.spotify.com/embed/")){let i=O.store.plugins?.FixSpotifyEmbeds;if(!i?.enabled)return;r.executeJavaScript(`
                    const original = Audio.prototype.play;
                    Audio.prototype.play = function() {
                        this.volume = ${i.volume/100||.1};
                        return original.apply(this, arguments);
                    }
                `)}})})});var en={};c();var Qt=require("electron");Qt.app.on("browser-window-created",(t,e)=>{e.webContents.on("frame-created",(n,{frame:r})=>{r?.once("dom-ready",()=>{if(r.url.startsWith("https://www.youtube.com/")){if(!O.store.plugins?.FixYoutubeEmbeds?.enabled)return;r.executeJavaScript(`
                new MutationObserver(() => {
                    if(
                        document.querySelector('div.ytp-error-content-wrap-subreason a[href*="www.youtube.com/watch?v="]')
                    ) location.reload()
                }).observe(document.body, { childList: true, subtree:true });
                `)}})})});var nt={};$(nt,{resolveRedirect:()=>br});c();var tn=require("https"),Tr=/^https:\/\/(spotify\.link|s\.team)\/.+$/;function nn(t){return new Promise((e,n)=>{let r=(0,tn.request)(new URL(t),{method:"HEAD"},i=>{e(i.headers.location?nn(i.headers.location):t)});r.on("error",n),r.end()})}async function br(t,e){return Tr.test(e)?nn(e):e}var rt={};$(rt,{makeDeeplTranslateRequest:()=>Er});c();async function Er(t,e,n,r){let i=e?"https://api.deepl.com/v2/translate":"https://api-free.deepl.com/v2/translate";try{let o=await fetch(i,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`DeepL-Auth-Key ${n}`},body:r}),s=await o.text();return{status:o.status,data:s}}catch(o){return{status:-1,data:String(o)}}}var it={};$(it,{readRecording:()=>Rr});c();var rn=require("electron"),on=require("fs/promises"),we=require("path");async function Rr(t,e){e=(0,we.normalize)(e);let n=(0,we.basename)(e),r=(0,we.normalize)(rn.app.getPath("userData")+"/");if(console.log(n,r,e),n!=="recording.ogg"||!e.startsWith(r))return null;try{let i=await(0,on.readFile)(e);return new Uint8Array(i.buffer)}catch{return null}}var ot={};$(ot,{sendToOverlay:()=>Dr});c();var an=require("dgram"),sn;function Dr(t,e){e.messageType=e.type;let n=JSON.stringify(e);sn??=(0,an.createSocket)("udp4"),sn.send(n,42069,"127.0.0.1")}var un={};c();var ln=require("electron");c();var cn=`/* eslint-disable */

/**
 * This file is part of AdGuard's Block YouTube Ads (https://github.com/AdguardTeam/BlockYouTubeAdsShortcut).
 *
 * Copyright (C) AdGuard Team
 *
 * AdGuard's Block YouTube Ads is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard's Block YouTube Ads is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard's Block YouTube Ads.  If not, see <http://www.gnu.org/licenses/>.
 */

const hiddenCSS = [
    "#__ffYoutube1",
    "#__ffYoutube2",
    "#__ffYoutube3",
    "#__ffYoutube4",
    "#feed-pyv-container",
    "#feedmodule-PRO",
    "#homepage-chrome-side-promo",
    "#merch-shelf",
    "#offer-module",
    '#pla-shelf > ytd-pla-shelf-renderer[class="style-scope ytd-watch"]',
    "#pla-shelf",
    "#premium-yva",
    "#promo-info",
    "#promo-list",
    "#promotion-shelf",
    "#related > ytd-watch-next-secondary-results-renderer > #items > ytd-compact-promoted-video-renderer.ytd-watch-next-secondary-results-renderer",
    "#search-pva",
    "#shelf-pyv-container",
    "#video-masthead",
    "#watch-branded-actions",
    "#watch-buy-urls",
    "#watch-channel-brand-div",
    "#watch7-branded-banner",
    "#YtKevlarVisibilityIdentifier",
    "#YtSparklesVisibilityIdentifier",
    ".carousel-offer-url-container",
    ".companion-ad-container",
    ".GoogleActiveViewElement",
    '.list-view[style="margin: 7px 0pt;"]',
    ".promoted-sparkles-text-search-root-container",
    ".promoted-videos",
    ".searchView.list-view",
    ".sparkles-light-cta",
    ".watch-extra-info-column",
    ".watch-extra-info-right",
    ".ytd-carousel-ad-renderer",
    ".ytd-compact-promoted-video-renderer",
    ".ytd-companion-slot-renderer",
    ".ytd-merch-shelf-renderer",
    ".ytd-player-legacy-desktop-watch-ads-renderer",
    ".ytd-promoted-sparkles-text-search-renderer",
    ".ytd-promoted-video-renderer",
    ".ytd-search-pyv-renderer",
    ".ytd-video-masthead-ad-v3-renderer",
    ".ytp-ad-action-interstitial-background-container",
    ".ytp-ad-action-interstitial-slot",
    ".ytp-ad-image-overlay",
    ".ytp-ad-overlay-container",
    ".ytp-ad-progress",
    ".ytp-ad-progress-list",
    '[class*="ytd-display-ad-"]',
    '[layout*="display-ad-"]',
    'a[href^="http://www.youtube.com/cthru?"]',
    'a[href^="https://www.youtube.com/cthru?"]',
    "ytd-action-companion-ad-renderer",
    "ytd-banner-promo-renderer",
    "ytd-compact-promoted-video-renderer",
    "ytd-companion-slot-renderer",
    "ytd-display-ad-renderer",
    "ytd-promoted-sparkles-text-search-renderer",
    "ytd-promoted-sparkles-web-renderer",
    "ytd-search-pyv-renderer",
    "ytd-single-option-survey-renderer",
    "ytd-video-masthead-ad-advertiser-info-renderer",
    "ytd-video-masthead-ad-v3-renderer",
    "YTM-PROMOTED-VIDEO-RENDERER",
];
/**
* Adds CSS to the page
*/
const hideElements = () => {
    const selectors = hiddenCSS;
    if (!selectors) {
        return;
    }
    const rule = selectors.join(", ") + " { display: none!important; }";
    const style = document.createElement("style");
    style.textContent = rule;
    document.head.appendChild(style);
};
/**
* Calls the "callback" function on every DOM change, but not for the tracked events
* @param {Function} callback callback function
*/
const observeDomChanges = callback => {
    const domMutationObserver = new MutationObserver(mutations => {
        callback(mutations);
    });
    domMutationObserver.observe(document.documentElement, {
        childList: true,
        subtree: true,
    });
};
/**
* This function is supposed to be called on every DOM change
*/
const hideDynamicAds = () => {
    const elements = document.querySelectorAll("#contents > ytd-rich-item-renderer ytd-display-ad-renderer");
    if (elements.length === 0) {
        return;
    }
    elements.forEach(el => {
        if (el.parentNode && el.parentNode.parentNode) {
            const parent = el.parentNode.parentNode;
            if (parent.localName === "ytd-rich-item-renderer") {
                parent.style.display = "none";
            }
        }
    });
};
/**
* This function checks if the video ads are currently running
* and auto-clicks the skip button.
*/
const autoSkipAds = () => {
    // If there's a video that plays the ad at this moment, scroll this ad
    if (document.querySelector(".ad-showing")) {
        const video = document.querySelector("video");
        if (video && video.duration) {
            video.currentTime = video.duration;
            // Skip button should appear after that,
            // now simply click it automatically
            setTimeout(() => {
                const skipBtn = document.querySelector("button.ytp-ad-skip-button");
                if (skipBtn) {
                    skipBtn.click();
                }
            }, 100);
        }
    }
};
/**
* This function overrides a property on the specified object.
*
* @param {object} obj object to look for properties in
* @param {string} propertyName property to override
* @param {*} overrideValue value to set
*/
const overrideObject = (obj, propertyName, overrideValue) => {
    if (!obj) {
        return false;
    }
    let overriden = false;
    for (const key in obj) {
        if (obj.hasOwnProperty(key) && key === propertyName) {
            obj[key] = overrideValue;
            overriden = true;
        } else if (obj.hasOwnProperty(key) && typeof obj[key] === "object") {
            if (overrideObject(obj[key], propertyName, overrideValue)) {
                overriden = true;
            }
        }
    }
    return overriden;
};
/**
* Overrides JSON.parse and Response.json functions.
* Examines these functions arguments, looks for properties with the specified name there
* and if it exists, changes it's value to what was specified.
*
* @param {string} propertyName name of the property
* @param {*} overrideValue new value for the property
*/
const jsonOverride = (propertyName, overrideValue) => {
    const nativeJSONParse = JSON.parse;
    JSON.parse = (...args) => {
        const obj = nativeJSONParse.apply(this, args);
        // Override it's props and return back to the caller
        overrideObject(obj, propertyName, overrideValue);
        return obj;
    };
    // Override Response.prototype.json
    Response.prototype.json = new Proxy(Response.prototype.json, {
        async apply(...args) {
            // Call the target function, get the original Promise
            const result = await Reflect.apply(...args);
            // Create a new one and override the JSON inside
            overrideObject(result, propertyName, overrideValue);
            return result;
        },
    });
};
// Removes ads metadata from YouTube XHR requests
jsonOverride("adPlacements", []);
jsonOverride("playerAds", []);
// Applies CSS that hides YouTube ad elements
hideElements();
// Some changes should be re-evaluated on every page change
hideDynamicAds();
autoSkipAds();
observeDomChanges(() => {
    hideDynamicAds();
    autoSkipAds();
});`;ln.app.on("browser-window-created",(t,e)=>{e.webContents.on("frame-created",(n,{frame:r})=>{r?.once("dom-ready",()=>{O.store.plugins?.YoutubeAdblock?.enabled&&(r.url.includes("youtube.com/embed/")||r.url.includes("discordsays")&&r.url.includes("youtube.com"))&&r.executeJavaScript(cn)})})});var st={};$(st,{debugEnv:()=>Pr,fetchCached:()=>Mr,fetchOnce:()=>_r,startBridge:()=>dn,stopBridge:()=>Or});c();var fn=require("child_process"),hn=bt(require("readline")),pn=bt(require("fs")),R=null,q=null,gn=null;function Pr(){return process.env.VC_AMBRIDGE_EXE||null}function kr(){let t=process.env.VC_AMBRIDGE_EXE;if(!t||!pn.existsSync(t))throw new Error("VC_AMBRIDGE_EXE \u672A\u8A2D\u5B9A/\u4E0D\u6B63: "+(t??"(\u672A\u8A2D\u5B9A)"));return t}function dn(){if(R)return{ok:!0,note:"already running",pid:R.pid};let t=kr();R=(0,fn.spawn)(t,[],{stdio:["ignore","pipe","pipe"],windowsHide:!0});let e=R.stdout;if(!e)throw new Error("stdout not available");return e.setEncoding?.("utf8"),q=hn.createInterface({input:e,crlfDelay:1/0,terminal:!1}),q.on("line",n=>{try{gn=JSON.parse(n)}catch{}}),R.stderr?.on("data",n=>console.error("[AMBridge][stderr]",String(n))),R.on("error",n=>console.error("[AMBridge] spawn error:",n)),R.on("exit",()=>{try{q?.close()}catch{}q=null,R=null}),{ok:!0,pid:R.pid,path:t}}function Or(){try{q?.close()}catch{}q=null;try{R?.kill()}catch{}return R=null,{ok:!0}}function Mr(){return gn}function _r(t=5e3){R||dn();let e=R,n=q;if(!e||!e.stdout||!n)throw new Error("readline/stdout not initialized");let r=e.stdout;return new Promise(i=>{let o=h=>{u();try{clearTimeout(d)}catch{}i(h)},s=h=>{try{o(JSON.parse(h))}catch{}},a=h=>{let l=typeof h=="string"?h:h.toString("utf8");for(let v of l.split(/\r?\n/)){let E=v.trim();if(E.startsWith("{")&&E.endsWith("}"))try{o(JSON.parse(E));return}catch{}}},u=()=>{n.off("line",s),r.off("data",a)};n.on("line",s),r.on("data",a);let d=setTimeout(()=>o({timeout:!0}),t)})}var mn={AppleMusicRichPresence:et,ConsoleShortcuts:tt,FixSpotifyEmbeds:qt,FixYoutubeEmbeds:en,OpenInApp:nt,Translate:rt,VoiceMessages:it,XSOverlay:ot,YoutubeAdblock:un,AppleMusicBridgeWin:st};var vn={};for(let[t,e]of Object.entries(mn)){let n=Object.entries(e);if(!n.length)continue;let r=vn[t]={};for(let[i,o]of n){let s=`VencordPluginNative_${t}_${i}`;at.ipcMain.handle(s,o),r[i]=s}}at.ipcMain.on("VencordGetPluginIpcMethodMap",t=>{t.returnValue=vn});c();se();var I=require("electron");c();var yn="PCFET0NUWVBFIGh0bWw+CjxodG1sIGxhbmc9ImVuIj4KICAgIDxoZWFkPgogICAgICAgIDxtZXRhIGNoYXJzZXQ9InV0Zi04IiAvPgogICAgICAgIDx0aXRsZT5WZW5jb3JkIFF1aWNrQ1NTIEVkaXRvcjwvdGl0bGU+CiAgICAgICAgPGxpbmsKICAgICAgICAgICAgcmVsPSJzdHlsZXNoZWV0IgogICAgICAgICAgICBocmVmPSJodHRwczovL2Nkbi5qc2RlbGl2ci5uZXQvbnBtL21vbmFjby1lZGl0b3JAMC41MC4wL21pbi92cy9lZGl0b3IvZWRpdG9yLm1haW4uY3NzIgogICAgICAgICAgICBpbnRlZ3JpdHk9InNoYTI1Ni10aUpQUTJPMDR6L3BaL0F3ZHlJZ2hyT016ZXdmK1BJdkVsMVlLYlF2c1prPSIKICAgICAgICAgICAgY3Jvc3NvcmlnaW49ImFub255bW91cyIKICAgICAgICAgICAgcmVmZXJyZXJwb2xpY3k9Im5vLXJlZmVycmVyIgogICAgICAgIC8+CiAgICAgICAgPHN0eWxlPgogICAgICAgICAgICBodG1sLAogICAgICAgICAgICBib2R5LAogICAgICAgICAgICAjY29udGFpbmVyIHsKICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTsKICAgICAgICAgICAgICAgIGxlZnQ6IDA7CiAgICAgICAgICAgICAgICB0b3A6IDA7CiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTsKICAgICAgICAgICAgICAgIGhlaWdodDogMTAwJTsKICAgICAgICAgICAgICAgIG1hcmdpbjogMDsKICAgICAgICAgICAgICAgIHBhZGRpbmc6IDA7CiAgICAgICAgICAgICAgICBvdmVyZmxvdzogaGlkZGVuOwogICAgICAgICAgICB9CiAgICAgICAgPC9zdHlsZT4KICAgIDwvaGVhZD4KCiAgICA8Ym9keT4KICAgICAgICA8ZGl2IGlkPSJjb250YWluZXIiPjwvZGl2PgogICAgICAgIDxzY3JpcHQKICAgICAgICAgICAgc3JjPSJodHRwczovL2Nkbi5qc2RlbGl2ci5uZXQvbnBtL21vbmFjby1lZGl0b3JAMC41MC4wL21pbi92cy9sb2FkZXIuanMiCiAgICAgICAgICAgIGludGVncml0eT0ic2hhMjU2LUtjVTQ4VEdyODRyN3VuRjdKNUlnQm85NWFlVnJFYnJHZTA0UzdUY0ZVanM9IgogICAgICAgICAgICBjcm9zc29yaWdpbj0iYW5vbnltb3VzIgogICAgICAgICAgICByZWZlcnJlcnBvbGljeT0ibm8tcmVmZXJyZXIiCiAgICAgICAgPjwvc2NyaXB0PgoKICAgICAgICA8c2NyaXB0PgogICAgICAgICAgICByZXF1aXJlLmNvbmZpZyh7CiAgICAgICAgICAgICAgICBwYXRoczogewogICAgICAgICAgICAgICAgICAgIHZzOiAiaHR0cHM6Ly9jZG4uanNkZWxpdnIubmV0L25wbS9tb25hY28tZWRpdG9yQDAuNTAuMC9taW4vdnMiLAogICAgICAgICAgICAgICAgfSwKICAgICAgICAgICAgfSk7CgogICAgICAgICAgICByZXF1aXJlKFsidnMvZWRpdG9yL2VkaXRvci5tYWluIl0sICgpID0+IHsKICAgICAgICAgICAgICAgIGdldEN1cnJlbnRDc3MoKS50aGVuKChjc3MpID0+IHsKICAgICAgICAgICAgICAgICAgICB2YXIgZWRpdG9yID0gbW9uYWNvLmVkaXRvci5jcmVhdGUoCiAgICAgICAgICAgICAgICAgICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCJjb250YWluZXIiKSwKICAgICAgICAgICAgICAgICAgICAgICAgewogICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IGNzcywKICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhbmd1YWdlOiAiY3NzIiwKICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoZW1lOiBnZXRUaGVtZSgpLAogICAgICAgICAgICAgICAgICAgICAgICB9CiAgICAgICAgICAgICAgICAgICAgKTsKICAgICAgICAgICAgICAgICAgICBlZGl0b3Iub25EaWRDaGFuZ2VNb2RlbENvbnRlbnQoKCkgPT4KICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q3NzKGVkaXRvci5nZXRWYWx1ZSgpKQogICAgICAgICAgICAgICAgICAgICk7CiAgICAgICAgICAgICAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoInJlc2l6ZSIsICgpID0+IHsKICAgICAgICAgICAgICAgICAgICAgICAgLy8gbWFrZSBtb25hY28gcmUtbGF5b3V0CiAgICAgICAgICAgICAgICAgICAgICAgIGVkaXRvci5sYXlvdXQoKTsKICAgICAgICAgICAgICAgICAgICB9KTsKICAgICAgICAgICAgICAgIH0pOwogICAgICAgICAgICB9KTsKICAgICAgICA8L3NjcmlwdD4KICAgIDwvYm9keT4KPC9odG1sPgo=";var Se=require("fs"),he=require("fs/promises"),fe=require("path");c();se();var ue=require("electron");function In(){ue.ipcMain.handle("VencordCspRemoveOverride",Vr),ue.ipcMain.handle("VencordCspRequestAddOverride",Ur),ue.ipcMain.handle("VencordCspIsDomainAllowed",Gr)}function Lr(t,e){try{let{host:n}=new URL(t);if(/[;'"\\]/.test(n))return!1}catch{return!1}return!(e.length===0||e.some(n=>!C.includes(n)))}function Nr(t,e,n){let r=new URL(t).host,i=`${n} wants to allow connections to ${r}`,o=`Unless you recognise and fully trust ${r}, you should cancel this request!

You will have to fully close and restart Vesktop for the changes to take effect.`;if(e.length===1&&e[0]==="connect-src")return{message:i,detail:o};let s=e.filter(a=>a!=="connect-src").map(a=>{switch(a){case"img-src":return"Images";case"style-src":return"CSS & Themes";case"font-src":return"Fonts";default:throw new Error(`Illegal CSP directive: ${a}`)}}).sort().join(", ");return o=`The following types of content will be allowed to load from ${r}:
${s}

${o}`,{message:i,detail:o}}async function Ur(t,e,n,r){if(!Lr(e,n))return"invalid";let i=new URL(e).host;if(i in U.store.customCspRules)return"conflict";let{checkboxChecked:o,response:s}=await ue.dialog.showMessageBox({...Nr(e,n,r),type:r?"info":"warning",title:"Vencord Host Permissions",buttons:["Cancel","Allow"],defaultId:0,cancelId:0,checkboxLabel:`I fully trust ${i} and understand the risks of allowing connections to it.`,checkboxChecked:!1});return s!==1?"cancelled":o?(U.store.customCspRules[i]=n,"ok"):"unchecked"}function Vr(t,e){return e in U.store.customCspRules?(delete U.store.customCspRules[e],!0):!1}function Gr(t,e,n){try{let r=new URL(e).host,i=$e[r]??U.store.customCspRules[r];return i?n.every(o=>i.includes(o)):!1}catch{return!1}}c();var zr=/[^\S\r\n]*?\r?(?:\r\n|\n)[^\S\r\n]*?\*[^\S\r\n]?/,Br=/^\\@/;function ct(t,e={}){return{fileName:t,name:e.name??t.replace(/\.css$/i,""),author:e.author??"Unknown Author",description:e.description??"A Discord Theme.",version:e.version,license:e.license,source:e.source,website:e.website,invite:e.invite}}function An(t){return t.charCodeAt(0)===65279&&(t=t.slice(1)),t}function Cn(t,e){if(!t)return ct(e);let n=t.split("/**",2)?.[1]?.split("*/",1)?.[0];if(!n)return ct(e);let r={},i="",o="";for(let s of n.split(zr))if(s.length!==0)if(s.charAt(0)==="@"&&s.charAt(1)!==" "){r[i]=o.trim();let a=s.indexOf(" ");i=s.substring(1,a),o=s.substring(a+1)}else o+=" "+s.replace("\\n",`
`).replace(Br,"@");return r[i]=o.trim(),delete r[""],ct(e,r)}c();var wn=require("electron");function Sn(t){t.webContents.setWindowOpenHandler(({url:e})=>{switch(e){case"about:blank":case"https://discord.com/popout":case"https://ptb.discord.com/popout":case"https://canary.discord.com/popout":return{action:"allow"}}try{var{protocol:n}=new URL(e)}catch{return{action:"deny"}}switch(n){case"http:":case"https:":case"mailto:":case"steam:":case"spotify:":wn.shell.openExternal(e)}return{action:"deny"}})}(0,Se.mkdirSync)(J,{recursive:!0});In();function lt(t,e){let n=(0,fe.normalize)(t+"/"),r=(0,fe.join)(t,e),i=(0,fe.normalize)(r);return i.startsWith(n)?i:null}function Fr(){return(0,he.readFile)(Pe,"utf-8").catch(()=>"")}async function jr(){let t=await(0,he.readdir)(J).catch(()=>[]),e=[];for(let n of t){if(!n.endsWith(".css"))continue;let r=await xn(n).then(An).catch(()=>null);r!=null&&e.push(Cn(r,n))}return e}function xn(t){t=t.replace(/\?v=\d+$/,"");let e=lt(J,t);return e?(0,he.readFile)(e,"utf-8"):Promise.reject(`Unsafe path ${t}`)}I.ipcMain.handle("VencordOpenQuickCss",()=>I.shell.openPath(Pe));I.ipcMain.handle("VencordOpenExternal",(t,e)=>{try{var{protocol:n}=new URL(e)}catch{throw"Malformed URL"}if(!Dt.includes(n))throw"Disallowed protocol.";I.shell.openExternal(e)});I.ipcMain.handle("VencordGetQuickCss",()=>Fr());I.ipcMain.handle("VencordSetQuickCss",(t,e)=>(0,Se.writeFileSync)(Pe,e));I.ipcMain.handle("VencordGetThemesList",()=>jr());I.ipcMain.handle("VencordGetThemeData",(t,e)=>xn(e));I.ipcMain.handle("VencordGetThemeSystemValues",()=>({"os-accent-color":`#${I.systemPreferences.getAccentColor?.()||""}`}));I.ipcMain.handle("VencordOpenThemesFolder",()=>I.shell.openPath(J));I.ipcMain.handle("VencordOpenSettingsFolder",()=>I.shell.openPath(Y));I.ipcMain.handle("VencordOpenMonacoEditor",async()=>{let t="Vencord QuickCSS Editor",e=I.BrowserWindow.getAllWindows().find(r=>r.title===t);if(e&&!e.isDestroyed()){e.focus();return}let n=new I.BrowserWindow({title:t,autoHideMenuBar:!0,darkTheme:!0,webPreferences:{preload:(0,fe.join)(__dirname,"vencordDesktopPreload.js"),contextIsolation:!0,nodeIntegration:!1,sandbox:!1}});Sn(n),await n.loadURL(`data:text/html;base64,${yn}`)});c();var Wn=require("electron");c();var En=require("module"),Zr=(0,En.createRequire)("/"),Me,Wr=";var __w=require('worker_threads');__w.parentPort.on('message',function(m){onmessage({data:m})}),postMessage=function(m,t){__w.parentPort.postMessage(m,t)},close=process.exit;self=global";try{Me=Zr("worker_threads").Worker}catch{}var Kr=Me?function(t,e,n,r,i){var o=!1,s=new Me(t+Wr,{eval:!0}).on("error",function(a){return i(a,null)}).on("message",function(a){return i(null,a)}).on("exit",function(a){a&&!o&&i(new Error("exited with code "+a),null)});return s.postMessage(n,r),s.terminate=function(){return o=!0,Me.prototype.terminate.call(s)},s}:function(t,e,n,r,i){setImmediate(function(){return i(new Error("async operations unsupported - update to Node 12+ (or Node 10-11 with the --experimental-worker CLI flag)"),null)});var o=function(){};return{terminate:o,postMessage:o}},b=Uint8Array,Q=Uint16Array,Rn=Int32Array,ht=new b([0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0,0,0]),pt=new b([0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,0,0]),Dn=new b([16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]),Pn=function(t,e){for(var n=new Q(31),r=0;r<31;++r)n[r]=e+=1<<t[r-1];for(var i=new Rn(n[30]),r=1;r<30;++r)for(var o=n[r];o<n[r+1];++o)i[o]=o-n[r]<<5|r;return{b:n,r:i}},kn=Pn(ht,2),gt=kn.b,Hr=kn.r;gt[28]=258,Hr[258]=28;var On=Pn(pt,0),Mn=On.b,jo=On.r,Ne=new Q(32768);for(m=0;m<32768;++m)j=(m&43690)>>1|(m&21845)<<1,j=(j&52428)>>2|(j&13107)<<2,j=(j&61680)>>4|(j&3855)<<4,Ne[m]=((j&65280)>>8|(j&255)<<8)>>1;var j,m,pe=function(t,e,n){for(var r=t.length,i=0,o=new Q(e);i<r;++i)t[i]&&++o[t[i]-1];var s=new Q(e);for(i=1;i<e;++i)s[i]=s[i-1]+o[i-1]<<1;var a;if(n){a=new Q(1<<e);var u=15-e;for(i=0;i<r;++i)if(t[i])for(var d=i<<4|t[i],h=e-t[i],l=s[t[i]-1]++<<h,v=l|(1<<h)-1;l<=v;++l)a[Ne[l]>>u]=d}else for(a=new Q(r),i=0;i<r;++i)t[i]&&(a[i]=Ne[s[t[i]-1]++]>>15-t[i]);return a},xe=new b(288);for(m=0;m<144;++m)xe[m]=8;var m;for(m=144;m<256;++m)xe[m]=9;var m;for(m=256;m<280;++m)xe[m]=7;var m;for(m=280;m<288;++m)xe[m]=8;var m,_n=new b(32);for(m=0;m<32;++m)_n[m]=5;var m;var Ln=pe(xe,9,1);var Nn=pe(_n,5,1),_e=function(t){for(var e=t[0],n=1;n<t.length;++n)t[n]>e&&(e=t[n]);return e},_=function(t,e,n){var r=e/8|0;return(t[r]|t[r+1]<<8)>>(e&7)&n},Le=function(t,e){var n=e/8|0;return(t[n]|t[n+1]<<8|t[n+2]<<16)>>(e&7)},Un=function(t){return(t+7)/8|0},Ue=function(t,e,n){return(e==null||e<0)&&(e=0),(n==null||n>t.length)&&(n=t.length),new b(t.subarray(e,n))};var Vn=["unexpected EOF","invalid block type","invalid length/literal","invalid distance","stream finished","no stream handler",,"no callback","invalid UTF-8 data","extra field too long","date not in range 1980-2099","filename too long","stream finishing","invalid zip data"],T=function(t,e,n){var r=new Error(e||Vn[t]);if(r.code=t,Error.captureStackTrace&&Error.captureStackTrace(r,T),!n)throw r;return r},Gn=function(t,e,n,r){var i=t.length,o=r?r.length:0;if(!i||e.f&&!e.l)return n||new b(0);var s=!n,a=s||e.i!=2,u=e.i;s&&(n=new b(i*3));var d=function(wt){var St=n.length;if(wt>St){var xt=new b(Math.max(St*2,wt));xt.set(n),n=xt}},h=e.f||0,l=e.p||0,v=e.b||0,E=e.l,te=e.d,z=e.m,D=e.n,P=i*8;do{if(!E){h=_(t,l,1);var Z=_(t,l+1,3);if(l+=3,Z)if(Z==1)E=Ln,te=Nn,z=9,D=5;else if(Z==2){var de=_(t,l,31)+257,Te=_(t,l+10,15)+4,H=de+_(t,l+5,31)+1;l+=14;for(var k=new b(H),re=new b(19),w=0;w<Te;++w)re[Dn[w]]=_(t,l+w*3,7);l+=Te*3;for(var me=_e(re),Yn=(1<<me)-1,Jn=pe(re,me,1),w=0;w<H;){var vt=Jn[_(t,l,Yn)];l+=vt&15;var x=vt>>4;if(x<16)k[w++]=x;else{var ie=0,be=0;for(x==16?(be=3+_(t,l,3),l+=2,ie=k[w-1]):x==17?(be=3+_(t,l,7),l+=3):x==18&&(be=11+_(t,l,127),l+=7);be--;)k[w++]=ie}}var yt=k.subarray(0,de),W=k.subarray(de);z=_e(yt),D=_e(W),E=pe(yt,z,1),te=pe(W,D,1)}else T(1);else{var x=Un(l)+4,B=t[x-4]|t[x-3]<<8,ne=x+B;if(ne>i){u&&T(0);break}a&&d(v+B),n.set(t.subarray(x,ne),v),e.b=v+=B,e.p=l=ne*8,e.f=h;continue}if(l>P){u&&T(0);break}}a&&d(v+131072);for(var Xn=(1<<z)-1,qn=(1<<D)-1,Ve=l;;Ve=l){var ie=E[Le(t,l)&Xn],oe=ie>>4;if(l+=ie&15,l>P){u&&T(0);break}if(ie||T(2),oe<256)n[v++]=oe;else if(oe==256){Ve=l,E=null;break}else{var It=oe-254;if(oe>264){var w=oe-257,ve=ht[w];It=_(t,l,(1<<ve)-1)+gt[w],l+=ve}var Ge=te[Le(t,l)&qn],ze=Ge>>4;Ge||T(3),l+=Ge&15;var W=Mn[ze];if(ze>3){var ve=pt[ze];W+=Le(t,l)&(1<<ve)-1,l+=ve}if(l>P){u&&T(0);break}a&&d(v+131072);var At=v+It;if(v<W){var Ct=o-W,Qn=Math.min(W,At);for(Ct+v<0&&T(3);v<Qn;++v)n[v]=r[Ct+v]}for(;v<At;++v)n[v]=n[v-W]}}e.l=E,e.p=Ve,e.b=v,e.f=h,E&&(h=1,e.m=z,e.d=te,e.n=D)}while(!h);return v!=n.length&&s?Ue(n,0,v):n.subarray(0,v)};var $r=new b(0);var Yr=function(t,e){var n={};for(var r in t)n[r]=t[r];for(var r in e)n[r]=e[r];return n},Tn=function(t,e,n){for(var r=t(),i=t.toString(),o=i.slice(i.indexOf("[")+1,i.lastIndexOf("]")).replace(/\s+/g,"").split(","),s=0;s<r.length;++s){var a=r[s],u=o[s];if(typeof a=="function"){e+=";"+u+"=";var d=a.toString();if(a.prototype)if(d.indexOf("[native code]")!=-1){var h=d.indexOf(" ",8)+1;e+=d.slice(h,d.indexOf("(",h))}else{e+=d;for(var l in a.prototype)e+=";"+u+".prototype."+l+"="+a.prototype[l].toString()}else e+=d}else n[u]=a}return e},Oe=[],Jr=function(t){var e=[];for(var n in t)t[n].buffer&&e.push((t[n]=new t[n].constructor(t[n])).buffer);return e},Xr=function(t,e,n,r){if(!Oe[n]){for(var i="",o={},s=t.length-1,a=0;a<s;++a)i=Tn(t[a],i,o);Oe[n]={c:Tn(t[s],i,o),e:o}}var u=Yr({},Oe[n].e);return Kr(Oe[n].c+";onmessage=function(e){for(var k in e.data)self[k]=e.data[k];onmessage="+e.toString()+"}",n,u,Jr(u),r)},qr=function(){return[b,Q,Rn,ht,pt,Dn,gt,Mn,Ln,Nn,Ne,Vn,pe,_e,_,Le,Un,Ue,T,Gn,dt,zn,Bn]};var zn=function(t){return postMessage(t,[t.buffer])},Bn=function(t){return t&&{out:t.size&&new b(t.size),dictionary:t.dictionary}},Qr=function(t,e,n,r,i,o){var s=Xr(n,r,i,function(a,u){s.terminate(),o(a,u)});return s.postMessage([t,e],e.consume?[t.buffer]:[]),function(){s.terminate()}};var V=function(t,e){return t[e]|t[e+1]<<8},N=function(t,e){return(t[e]|t[e+1]<<8|t[e+2]<<16|t[e+3]<<24)>>>0},ut=function(t,e){return N(t,e)+N(t,e+4)*4294967296};function ei(t,e,n){return n||(n=e,e={}),typeof n!="function"&&T(7),Qr(t,e,[qr],function(r){return zn(dt(r.data[0],Bn(r.data[1])))},1,n)}function dt(t,e){return Gn(t,{i:2},e&&e.out,e&&e.dictionary)}var ft=typeof TextDecoder<"u"&&new TextDecoder,ti=0;try{ft.decode($r,{stream:!0}),ti=1}catch{}var ni=function(t){for(var e="",n=0;;){var r=t[n++],i=(r>127)+(r>223)+(r>239);if(n+i>t.length)return{s:e,r:Ue(t,n-1)};i?i==3?(r=((r&15)<<18|(t[n++]&63)<<12|(t[n++]&63)<<6|t[n++]&63)-65536,e+=String.fromCharCode(55296|r>>10,56320|r&1023)):i&1?e+=String.fromCharCode((r&31)<<6|t[n++]&63):e+=String.fromCharCode((r&15)<<12|(t[n++]&63)<<6|t[n++]&63):e+=String.fromCharCode(r)}};function ri(t,e){if(e){for(var n="",r=0;r<t.length;r+=16384)n+=String.fromCharCode.apply(null,t.subarray(r,r+16384));return n}else{if(ft)return ft.decode(t);var i=ni(t),o=i.s,n=i.r;return n.length&&T(8),o}}var ii=function(t,e){return e+30+V(t,e+26)+V(t,e+28)},oi=function(t,e,n){var r=V(t,e+28),i=ri(t.subarray(e+46,e+46+r),!(V(t,e+8)&2048)),o=e+46+r,s=N(t,e+20),a=n&&s==4294967295?si(t,o):[s,N(t,e+24),N(t,e+42)],u=a[0],d=a[1],h=a[2];return[V(t,e+10),u,d,i,o+V(t,e+30)+V(t,e+32),h]},si=function(t,e){for(;V(t,e)!=1;e+=4+V(t,e+2));return[ut(t,e+12),ut(t,e+4),ut(t,e+20)]};var bn=typeof queueMicrotask=="function"?queueMicrotask:typeof setTimeout=="function"?setTimeout:function(t){t()};function Fn(t,e,n){n||(n=e,e={}),typeof n!="function"&&T(7);var r=[],i=function(){for(var D=0;D<r.length;++D)r[D]()},o={},s=function(D,P){bn(function(){n(D,P)})};bn(function(){s=n});for(var a=t.length-22;N(t,a)!=101010256;--a)if(!a||t.length-a>65558)return s(T(13,0,1),null),i;var u=V(t,a+8);if(u){var d=u,h=N(t,a+16),l=h==4294967295||d==65535;if(l){var v=N(t,a-12);l=N(t,v)==101075792,l&&(d=u=N(t,v+32),h=N(t,v+48))}for(var E=e&&e.filter,te=function(D){var P=oi(t,h,l),Z=P[0],x=P[1],B=P[2],ne=P[3],de=P[4],Te=P[5],H=ii(t,Te);h=de;var k=function(w,me){w?(i(),s(w,null)):(me&&(o[ne]=me),--u||s(null,o))};if(!E||E({name:ne,size:x,originalSize:B,compression:Z}))if(!Z)k(null,Ue(t,H,H+x));else if(Z==8){var re=t.subarray(H,H+x);if(B<524288||x>.8*B)try{k(null,dt(re,{out:new b(B)}))}catch(w){k(w,null)}else r.push(ei(re,{size:B},k))}else k(T(14,"unknown compression type "+Z,1),null);else k(null,null)},z=0;z<d;++z)te(z)}else s(null,{});return i}var Kn=require("fs"),G=require("fs/promises"),ge=require("path");c();function jn(t){function e(s,a,u,d){let h=0;return h+=s<<0,h+=a<<8,h+=u<<16,h+=d<<24>>>0,h}if(t[0]===80&&t[1]===75&&t[2]===3&&t[3]===4)return t;if(t[0]!==67||t[1]!==114||t[2]!==50||t[3]!==52)throw new Error("Invalid header: Does not start with Cr24");let n=t[4]===3,r=t[4]===2;if(!r&&!n||t[5]||t[6]||t[7])throw new Error("Unexpected crx format version number.");if(r){let s=e(t[8],t[9],t[10],t[11]),a=e(t[12],t[13],t[14],t[15]),u=16+s+a;return t.subarray(u,t.length)}let o=12+e(t[8],t[9],t[10],t[11]);return t.subarray(o,t.length)}c();var ai=require("original-fs");async function ci(t,e){try{var n=await fetch(t,e)}catch(i){throw i instanceof Error&&i.cause&&(i=i.cause),new Error(`${e?.method??"GET"} ${t} failed: ${i}`)}if(n.ok)return n;let r=`${e?.method??"GET"} ${t}: ${n.status} ${n.statusText}`;try{let i=await n.text();r+=`
${i}`}catch{}throw new Error(r)}async function Zn(t,e){let r=await(await ci(t,e)).arrayBuffer();return Buffer.from(r)}var li=(0,ge.join)(De,"ExtensionCache");async function ui(t,e){return await(0,G.mkdir)(e,{recursive:!0}),new Promise((n,r)=>{Fn(t,(i,o)=>{if(i)return void r(i);Promise.all(Object.keys(o).map(async s=>{if(s.startsWith("_metadata/"))return;if(s.endsWith("/"))return void(0,G.mkdir)((0,ge.join)(e,s),{recursive:!0});let a=s.split("/"),u=a.pop(),d=a.join("/"),h=(0,ge.join)(e,d);d&&await(0,G.mkdir)(h,{recursive:!0}),await(0,G.writeFile)((0,ge.join)(h,u),o[s])})).then(()=>n()).catch(s=>{(0,G.rm)(e,{recursive:!0,force:!0}),r(s)})})})}async function Hn(t){let e=(0,ge.join)(li,`${t}`);try{await(0,G.access)(e,Kn.constants.F_OK)}catch{let r=`https://clients2.google.com/service/update2/crx?response=redirect&acceptformat=crx2,crx3&x=id%3D${t}%26uc&prodversion=${process.versions.chrome}`,i=await Zn(r,{headers:{"User-Agent":`Electron ${process.versions.electron} ~ Vencord (https://github.com/Vendicated/Vencord)`}});await ui(jn(i),e).catch(o=>console.error(`Failed to extract extension ${t}`,o))}Wn.session.defaultSession.loadExtension(e)}ee.app.whenReady().then(()=>{ee.protocol.handle("vencord",({url:t})=>{let e=decodeURI(t).slice(10).replace(/\?v=\d+$/,"");if(e.endsWith("/")&&(e=e.slice(0,-1)),e.startsWith("/themes/")){let n=e.slice(8),r=lt(J,n);return r?ee.net.fetch((0,mt.pathToFileURL)(r).toString()):new Response(null,{status:404})}switch(e){case"renderer.js.map":case"vencordDesktopRenderer.js.map":case"preload.js.map":case"vencordDesktopPreload.js.map":case"patcher.js.map":case"vencordDesktopMain.js.map":return ee.net.fetch((0,mt.pathToFileURL)((0,$n.join)(__dirname,e)).toString());default:return new Response(null,{status:404})}});try{O.store.enableReactDevtools&&Hn("fmkadmapgofadopljbjfkapdkoienihi").then(()=>console.info("[Vencord] Installed React Developer Tools")).catch(t=>console.error("[Vencord] Failed to install React Developer Tools",t))}catch{}_t()});
//# sourceURL=file:///VencordDesktopMain
//# sourceMappingURL=vencord://vencordDesktopMain.js.map
/*! For license information please see vencordDesktopMain.js.LEGAL.txt */
